﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace francesco.corbelli._4i.WPFThreads
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        const int GIRI = 1000;
        int _counter = 0;


        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Thread thread1 = new Thread(incrementa1);
            thread1.Start();

            Thread thread2 = new Thread(incrementa2);
            thread2.Start();
        }

        ///processo lento che dobbiamo lanciare
        private void incrementa1()
        {
            for (int x = 0; x < GIRI; x++)
            {
                _counter++;

                Dispatcher.Invoke(

                    () =>

                    {
                        lblCounter1.Text = x.ToString();
                    }

                    );

                Thread.Sleep(50);
            }
        }
        private void incrementa2()
        {
            for (int x = 0; x < GIRI; x++)
            {
                _counter++;

                Dispatcher.Invoke(

                    () =>

                    {
                        lblCounter2.Text = x.ToString();
                    }

                    );

                Thread.Sleep(50);
            }
        }
    }
}
